public class JantarFilosofosSemDeadlock {

    public static void main(String[] args) {
        int n = 5;
        Garfo[] garfos = new Garfo[n];
        for (int i = 0; i < n; i++) {
            garfos[i] = new Garfo(i);
        }

        Filosofo[] filosofos = new Filosofo[n];
        for (int i = 0; i < n; i++) {
            Garfo garfoEsquerda = garfos[i];
            Garfo garfoDireita = garfos[(i + 1) % n];
            filosofos[i] = new Filosofo(i, garfoEsquerda, garfoDireita);
            filosofos[i].start();
        }
    }

    static class Garfo {
        private final int id;
        private boolean ocupado;

        public Garfo(int id) {
            this.id = id;
            this.ocupado = false;
        }

        public synchronized void adquirir() {
            while (ocupado) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            ocupado = true;
        }

        public synchronized void liberar() {
            ocupado = false;
            notifyAll();
        }

        public int getId() {
            return id;
        }
    }

    static class Filosofo extends Thread {
        private final int id;
        private final Garfo garfoEsquerdaReal;
        private final Garfo garfoDireitaReal;
        private String estado;

        public Filosofo(int id, Garfo garfoEsquerdaReal, Garfo garfoDireitaReal) {
            this.id = id;
            this.garfoEsquerdaReal = garfoEsquerdaReal;
            this.garfoDireitaReal = garfoDireitaReal;
            this.estado = "pensando";
        }

        @Override
        public void run() {
            while (true) {
                pensar();
                estado = "com fome";
                System.out.println("Filosofo " + id + " está " + estado);

                Garfo garfoMenor;
                Garfo garfoMaior;

                if (garfoEsquerdaReal.getId() < garfoDireitaReal.getId()) {
                    garfoMenor = garfoEsquerdaReal;
                    garfoMaior = garfoDireitaReal;
                } else {
                    garfoMenor = garfoDireitaReal;
                    garfoMaior = garfoEsquerdaReal;
                }

                garfoMenor.adquirir();
                System.out.println("Filosofo " + id + " pegou garfo " + garfoMenor.getId());
                garfoMaior.adquirir();
                System.out.println("Filosofo " + id + " pegou garfo " + garfoMaior.getId());

                estado = "comendo";
                System.out.println("Filosofo " + id + " está " + estado);
                comer();

                garfoMaior.liberar();
                System.out.println("Filosofo " + id + " largou garfo " + garfoMaior.getId());
                garfoMenor.liberar();
                System.out.println("Filosofo " + id + " largou garfo " + garfoMenor.getId());

                estado = "pensando";
                System.out.println("Filosofo " + id + " está " + estado);
            }
        }

        private void pensar() {
            try {
                Thread.sleep((long) (Math.random() * 1000));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        private void comer() {
            try {
                Thread.sleep((long) (Math.random() * 1000));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
