import java.util.concurrent.*;

public class DeadlockDemo {

    static final Object TRAVA_A = new Object();
    static final Object TRAVA_B = new Object();

    public static void main(String[] args) {
        Thread t1 = new Thread(() -> {
            synchronized (TRAVA_A) {
                System.out.println("T1 pegou TRAVA_A");
                dormir(50);
                System.out.println("T1 tentando pegar TRAVA_B");
                synchronized (TRAVA_B) {
                    System.out.println("T1 concluiu");
                }
            }
        });

        Thread t2 = new Thread(() -> {
            synchronized (TRAVA_B) {
                System.out.println("T2 pegou TRAVA_B");
                dormir(50);
                System.out.println("T2 tentando pegar TRAVA_A");
                synchronized (TRAVA_A) {
                    System.out.println("T2 concluiu");
                }
            }
        });

        t1.start();
        t2.start();
    }

    static void dormir(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
