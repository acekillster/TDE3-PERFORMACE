public class JantarFilosofosDeadlock {

    public static void main(String[] args) {
        int n = 5;
        Garfo[] garfos = new Garfo[n];
        for (int i = 0; i < n; i++) {
            garfos[i] = new Garfo(i);
        }

        Filosofo[] filosofos = new Filosofo[n];
        for (int i = 0; i < n; i++) {
            Garfo garfoEsquerda = garfos[i];
            Garfo garfoDireita = garfos[(i + 1) % n];
            filosofos[i] = new Filosofo(i, garfoEsquerda, garfoDireita);
            filosofos[i].start();
        }
    }

    static class Garfo {
        private final int id;
        private boolean ocupado;

        public Garfo(int id) {
            this.id = id;
            this.ocupado = false;
        }

        public synchronized void adquirir() {
            while (ocupado) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            ocupado = true;
        }

        public synchronized void liberar() {
            ocupado = false;
            notifyAll();
        }

        public int getId() {
            return id;
        }
    }

    static class Filosofo extends Thread {
        private final int id;
        private final Garfo garfoEsquerda;
        private final Garfo garfoDireita;
        private String estado;

        public Filosofo(int id, Garfo garfoEsquerda, Garfo garfoDireita) {
            this.id = id;
            this.garfoEsquerda = garfoEsquerda;
            this.garfoDireita = garfoDireita;
            this.estado = "pensando";
        }

        @Override
        public void run() {
            while (true) {
                pensar();
                estado = "com fome";
                System.out.println("Filosofo " + id + " está " + estado);
                garfoEsquerda.adquirir();
                System.out.println("Filosofo " + id + " pegou garfo esquerdo " + garfoEsquerda.getId());
                garfoDireita.adquirir();
                System.out.println("Filosofo " + id + " pegou garfo direito " + garfoDireita.getId());
                estado = "comendo";
                System.out.println("Filosofo " + id + " está " + estado);
                comer();
                garfoDireita.liberar();
                System.out.println("Filosofo " + id + " largou garfo direito " + garfoDireita.getId());
                garfoEsquerda.liberar();
                System.out.println("Filosofo " + id + " largou garfo esquerdo " + garfoEsquerda.getId());
                estado = "pensando";
                System.out.println("Filosofo " + id + " está " + estado);
            }
        }

        private void pensar() {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        private void comer() {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

    }
}
